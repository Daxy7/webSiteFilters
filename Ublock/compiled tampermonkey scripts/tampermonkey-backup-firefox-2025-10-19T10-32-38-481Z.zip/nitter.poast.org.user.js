// ==UserScript==
// @name               nitter.poast.org
// @namespace          https://greasyfork.org/en/users/105361-randomusername404
// @description        Always redirects to Nitter, avoiding X's download speed.
// @match            *://twitter.com/*
// @match            *://x.com/*
// @version            1.02
// @run-at             document-start
// @author             RandomUsername404
// @grant              none
// @icon               https://twitter.com/favicon.ico
// ==/UserScript==

window.location.replace("https://nitter.poast.org" + window.location.pathname + window.location.search);