// ==UserScript==
// @name               Bring Back Embed Twitter
// @namespace          https://greasyfork.org/en/users/105361-randomusername404
// @description        Always redirects to Embed, avoiding Elon Musk's billionaire losses.
// @match            *://twitter.com/*
// @match            *://nitter.net/*
// @version            1.02
// @run-at             document-start
// @author             RandomUsername404
// @grant              none
// @icon               https://www.google.com/s2/favicons?domain=twitter.com
// ==/UserScript==

window.location.replace("https://syndication.twitter.com/srv/timeline-profile/screen-name" + window.location.pathname + window.location.search);