// ==UserScript==
// @name               piped.video
// @namespace          https://greasyfork.org/en/users/105361-randomusername404
// @description        Always redirects to piped.video, avoiding invidious instances.
// @match *://inv.nadeko.net/*
// @match *://invidious.fdn.fr/*
// @match *://invidious.flokinet.to/*
// @match *://invidious.lunar.icu/*
// @match *://yewtu.be/*
// @version            1.02
// @run-at             document-start
// @author             RandomUsername404
// @grant              none
// @icon               https://www.youtube.com/favicon.ico
// ==/UserScript==

window.location.replace("https://piped.video" + window.location.pathname + window.location.search);