// ==UserScript==
// @name               invidious.f5.si
// @namespace          https://greasyfork.org/en/users/105361-randomusername404
// @description        Always redirects to New Invidious Instance.
// @match            *://yewtu.be/*
// @version            1.02
// @run-at             document-start
// @author             RandomUsername404
// @grant              none
// @icon               https://www.youtube.com/favicon.ico
// ==/UserScript==

window.location.replace("https://invidious.f5.si" + window.location.pathname + window.location.search);