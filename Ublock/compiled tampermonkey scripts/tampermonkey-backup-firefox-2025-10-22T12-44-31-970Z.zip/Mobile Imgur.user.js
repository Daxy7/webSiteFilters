// ==UserScript==
// @name               Mobile Imgur
// @namespace          https://greasyfork.org/en/users/105361-randomusername404
// @description        Always redirects to Mobile, avoiding the Desktop design.
// @match            *://imgur.com/*
// @version            1.02
// @run-at             document-start
// @author             RandomUsername404
// @grant              none
// @icon
// ==/UserScript==

window.location.replace("https://imgur.io" + window.location.pathname + window.location.search);