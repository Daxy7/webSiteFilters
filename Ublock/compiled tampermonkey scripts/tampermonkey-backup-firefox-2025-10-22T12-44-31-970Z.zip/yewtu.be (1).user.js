// ==UserScript==
// @name               yewtu.be
// @namespace          https://greasyfork.org/en/users/105361-randomusername404
// @description        Always redirects to Invidious, avoiding YT's download speed.
// @match            *://www.youtube.com/*
// @version            1.02
// @run-at             document-start
// @author             RandomUsername404
// @grant              none
// @icon               https://www.youtube.com/favicon.ico
// ==/UserScript==

window.location.replace("https://yewtu.be" + window.location.pathname + window.location.search);