// ==UserScript==
// @name          Twitter: view more replies and remove useless sections
// @description   View more replies and remove useless sections from twitter
// @author        MK
// @namespace     max44
// @homepage      https://greasyfork.org/en/users/309172-max44
// @match         *://twitter.com/*
// @match         *://mobile.twitter.com/*
// @icon          https://www.google.com/s2/favicons?domain=twitter.com
// @version       1.8.4
// @license       MIT
// @require       https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js
// @grant         none
// @run-at        document-idle
// ==/UserScript==

(function () {
  'use strict';

  //Remove filter from sensitive content
  var css = `
  /*No filter for sensitive content*/
  .r-yfv4eo {
    filter: none !important;
  }
  `;

  const rootCallback = function (mutationsList, observer) {
    //==== Hide inline promtps :: timeline
    $( "div[data-testid='cellInnerDiv'] > div > div > div > div[data-testid='inlinePrompt']" ).parent().parent().parent().parent().hide(); //any language

    //==== Hide sensitive content warning :: timeline and tweet
    $( "article div:not([role='button']) > div[role='button'][tabindex='0'][style^='backdrop-filter: blur']" ).parent().parent().hide(); //any language

    //==== Click "Show replies" button :: tweet
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > div > span:contains('Show replies')" ).click(); //en
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > div > span:contains('Показати відповіді')" ).click(); //uk
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > div > span:contains('显示回复')" ).click(); //zh
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > div > span:contains('顯示回覆')" ).click(); //zh-traditional
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > div > span:contains('Mostrar respuestas')" ).click(); //es
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > div > span:contains('Voir les réponses')" ).click(); //fr
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > div > span:contains('返信を表示')" ).click(); //ja

    //==== Click "Show more replies" button :: tweet
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > span:contains('Show more replies')" ).click(); //en
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > span:contains('Показати більше відповідей')" ).click(); //uk
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > span:contains('显示更多回复')" ).click(); //zh
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > span:contains('顯示更多回覆')" ).click(); //zh-traditional
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > span:contains('Mostrar más respuestas')" ).click(); //es
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > span:contains('Voir plus de réponses')" ).click(); //fr
    $( "div[data-testid='primaryColumn'] div[role='button'][tabindex='0'] > div > div > span:contains('返信をさらに表示')" ).click(); //ja

    //==== Click "Show additional replies, including those that may contain offensive content" button :: tweet
    $( "div[data-testid='primaryColumn'] article div[role='button'][tabindex='0']:not([style^='backdrop-filter: blur']) > div > span > span:contains('Show')" ).click(); //en. "not blur" condition - to avoid click on "show sensitive content" button, as it hangs browser with Japanese interface
    $( "div[data-testid='primaryColumn'] article div[role='button'][tabindex='0']:not([style^='backdrop-filter: blur']) > div > span > span:contains('Показати')" ).click(); //uk
    $( "div[data-testid='primaryColumn'] article div[role='button'][tabindex='0']:not([style^='backdrop-filter: blur']) > div > span > span:contains('显示')" ).click(); //zh
    $( "div[data-testid='primaryColumn'] article div[role='button'][tabindex='0']:not([style^='backdrop-filter: blur']) > div > span > span:contains('顯示')" ).click(); //zh-traditional
    $( "div[data-testid='primaryColumn'] article div[role='button'][tabindex='0']:not([style^='backdrop-filter: blur']) > div > span > span:contains('Mostrar')" ).click(); //es
    $( "div[data-testid='primaryColumn'] article div[role='button'][tabindex='0']:not([style^='backdrop-filter: blur']) > div > span > span:contains('Voir')" ).click(); //fr
    $( "div[data-testid='primaryColumn'] article div[role='button'][tabindex='0']:not([style^='backdrop-filter: blur']) > div > span > span:contains('表示')" ).click(); //ja

    //==== Hide section "Who to follow" :: timeline (right column)
    $( "aside[aria-label='Who to follow']" ).parent().hide(); //en
    $( "aside[aria-label='Рекомендовані']" ).parent().hide(); //uk
    $( "aside[aria-label='推荐关注']" ).parent().hide(); //zh
    $( "aside[aria-label='跟隨誰']" ).parent().hide(); //zh-traditional
    $( "aside[aria-label='A quién seguir']" ).parent().hide(); //es
    $( "aside[aria-label='Suggestions']" ).parent().hide(); //fr
    $( "aside[aria-label='おすすめユーザー']" ).parent().hide(); //ja

    //==== Hide section "Who to follow" :: user profile
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Who to follow')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //en
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Рекомендації')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //uk
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('推荐关注')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //zh
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('跟隨誰')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //zh-traditional
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('A quién seguir')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //es
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Qui suivre')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //fr
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('おすすめユーザー')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //ja

    //==== Hide section "Trends for you" :: timeline (right column)
    $( "section[role='region'] > div[aria-label='Timeline: Trending now']" ).parent().parent().hide(); //en
    $( "section[role='region'] > div[aria-label='Стрічка: Актуальне зараз']" ).parent().parent().hide(); //uk
    $( "section[role='region'] > div[aria-label='时间线：当前趋势']" ).parent().parent().hide(); //zh
    $( "section[role='region'] > div[aria-label='時間軸：流行趨勢']" ).parent().parent().hide(); //zh-traditional
    $( "section[role='region'] > div[aria-label='Cronología: Tendencias del momento']" ).parent().parent().hide(); //es
    $( "section[role='region'] > div[aria-label='Fil d\'actualités : Tendance actuellement']" ).parent().parent().hide(); //fr
    $( "section[role='region'] > div[aria-label='タイムライン: トレンド']" ).parent().parent().hide(); //ja

    //==== Hide section "What's happening" :: timeline (right column)
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('What's happening')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //en
    //$( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //uk - not found
    //$( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //zh - not found
    //$( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //zh-traditional - not found
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Qué está pasando')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //es
    //$( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //fr - not found
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('いまどうしてる？')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //ja

    //==== Hide section "Trends for you" :: explore
    $( "div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Trends for you')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //en
    $( "div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Тренди для вас')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //uk
    $( "div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('你的趋势')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //zh
    $( "div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('你的流行趨勢')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //zh-traditional
    $( "div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Tendencias para ti')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //es
    $( "div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Tendances pour vous')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //fr
    //$( "div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //ja - not found

    //==== Hide message "You seem to be in a new location" :: explore
    $( "div > div > div > div > div > h1 > span:contains('You seem to be in a new location')" ).parent().parent().parent().parent().parent().parent().hide(); //en
    $( "div > div > div > div > div > h1 > span:contains('Схоже, ви перебуваєте в новому місці')" ).parent().parent().parent().parent().parent().parent().hide(); //uk
    $( "div > div > div > div > div > h1 > span:contains('你似乎到了一个新位置')" ).parent().parent().parent().parent().parent().parent().hide(); //zh
    $( "div > div > div > div > div > h1 > span:contains('你似乎位於新的位置')" ).parent().parent().parent().parent().parent().parent().hide(); //zh-traditional
    $( "div > div > div > div > div > h1 > span:contains('Parece que estás en una nueva ubicación')" ).parent().parent().parent().parent().parent().parent().hide(); //es
    $( "div > div > div > div > div > h1 > span:contains('Vous semblez vous trouver dans un nouveau lieu')" ).parent().parent().parent().parent().parent().parent().hide(); //fr
    //$( "div > div > div > div > div > h1 > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide(); //ja - not found

    //==== Hide section "Topics to follow" :: user profile
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Topic to follow')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //en
    //$( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //uk - not found
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('要关注的话题')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //zh
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('可跟隨的主題')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //zh-traditional
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Temas para seguir')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //es
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Sujets à suivre')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //fr
    $( "div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('おすすめトピック')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //ja

    //==== Hide section "Suggested topics" :: more -> topics
    $( "div[style='-webkit-line-clamp: 3;'] > span:contains('Suggested Topics')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //en
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //uk - not found
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //zh - not found
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //zh-traditional - not found
    $( "div[style='-webkit-line-clamp: 3;'] > span:contains('Temas sugeridos')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //es
    $( "div[style='-webkit-line-clamp: 3;'] > span:contains('Sujets suggérés')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //fr
    $( "div[style='-webkit-line-clamp: 3;'] > span:contains('おすすめトピック')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //ja

    //==== Hide section "Discover new Lists" :: lists
    $( "div[style='-webkit-line-clamp: 3;'] > span:contains('Discover new Lists')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //en
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //uk - not found
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //zh - not found
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //zh-traditional - not found
    $( "div[style='-webkit-line-clamp: 3;'] > span:contains('Descubre Listas nuevas')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //es
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //fr - not found
    $( "div[style='-webkit-line-clamp: 3;'] > span:contains('新しいリストを見つける')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //ja

    //==== Hide section "Expand your timeline with Topics" :: timeline
    $( "div[style='-webkit-line-clamp: 3;'] > span:contains('Expand your timeline with Topics')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //en
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //uk - not found
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //zh - not found
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //zh-traditional - not found
    $( "div[style='-webkit-line-clamp: 3;'] > span:contains('Amplía tu cronología con Temas')" ).parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide().next().hide().next().hide(); //es
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //fr - not found
    //$( "div[style='-webkit-line-clamp: 3;'] > span:contains('???')" ).parent().parent().parent().parent().parent().parent().hide().next().hide().next().hide().next().hide(); //ja - not found

    //==== Hide message "Concerned about your digital security?" :: timeline
    $( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('Concerned about your digital security?')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //en
    $( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('Є сумніви щодо цифрової безпеки?')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //uk
    //$( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //zh - not found
    //$( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //zh-traditional - not found
    //$( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //es - not found
    //$( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //fr - not found
    //$( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //ja - not found

    //==== Hide button "Open app" :: tweet on mobile browser
    $( "div[aria-label='Open app']" ).parent().hide(); //en
    $( "div[aria-label='Відкрити додаток']" ).parent().hide(); //uk
    $( "div[aria-label='打开应用']" ).parent().hide(); //zh
    $( "div[aria-label='開啟應用程式']" ).parent().hide(); //zh-traditional
    $( "div[aria-label='Abrir aplicación']" ).parent().hide(); //es
    $( "div[aria-label='Ouvrir l\'application']" ).parent().hide(); //fr
    //$( "div[aria-label='???']" ).parent().hide(); //ja - not found

    //==== Hide button "Get the app" :: timeline on mobile browser
    $( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('Get the app')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //en
    //$( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //uk - not found
    //$( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //zh - not found
    //$( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //zh-traditional - not found
    //$( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('???')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //es - not found
    $( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('Ouvrir l\'application')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //fr
    $( "div[data-testid='inlinePrompt'] > h1[role='heading'] > span > span > span:contains('アプリを開く')" ).parent().parent().parent().parent().parent().parent().parent().hide().next().hide(); //ja

    //==== Hide button "Get the app" :: tweet on mobile browser
    $( "div > div > div[role='button'][aria-label='Get the app']" ).parent().parent().hide(); //en
    //$( "div > div > div[role='button'][aria-label='???']" ).parent().parent().hide(); //uk - not found
    //$( "div > div > div[role='button'][aria-label='???']" ).parent().parent().hide(); //zh - not found
    //$( "div > div > div[role='button'][aria-label='???']" ).parent().parent().hide(); //zh-traditional - not found
    //$( "div > div > div[role='button'][aria-label='???']" ).parent().parent().hide(); //es - not found
    $( "div > div > div[role='button'][aria-label='Ouvrir l\'application']" ).parent().parent().hide(); //fr
    $( "div > div > div[role='button'][aria-label='アプリを開く']" ).parent().parent().hide(); //ja

    //==== Hide tweet "Promoted" :: timeline
    $( "div[data-testid='placementTracking'] > div > article > div > div > div > div > div > div > div > div > div > span:contains('Promoted')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //en
    $( "div[data-testid='placementTracking'] > div > article > div > div > div > div > div > div > div > div > div > span:contains('Реклама')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //uk
    $( "div[data-testid='placementTracking'] > div > article > div > div > div > div > div > div > div > div > div > span:contains('推荐')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //zh
    $( "div[data-testid='placementTracking'] > div > article > div > div > div > div > div > div > div > div > div > span:contains('推廣')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //zh-traditional
    $( "div[data-testid='placementTracking'] > div > article > div > div > div > div > div > div > div > div > div > span:contains('Promocionado')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //es
    $( "div[data-testid='placementTracking'] > div > article > div > div > div > div > div > div > div > div > div > span:contains('Sponsorisé')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //fr - not found
    $( "div[data-testid='placementTracking'] > div > article > div > div > div > div > div > div > div > div > div > span:contains('プロモーション')" ).parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().parent().hide(); //ja - not found

    //==== Hide tweet "Promoted Tweet" :: user profile
    $( "div[data-testid='cellInnerDiv'] > div > div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Promoted Tweet')" ).parent().parent().parent().parent().parent().parent().hide(); //en
    $( "div[data-testid='cellInnerDiv'] > div > div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Рекламований твіт')" ).parent().parent().parent().parent().parent().parent().hide(); //uk
    $( "div[data-testid='cellInnerDiv'] > div > div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('推广推文')" ).parent().parent().parent().parent().parent().parent().hide(); //zh
    $( "div[data-testid='cellInnerDiv'] > div > div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('推廣推文')" ).parent().parent().parent().parent().parent().parent().hide(); //zh-traditional
    $( "div[data-testid='cellInnerDiv'] > div > div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Tweet promocionado')" ).parent().parent().parent().parent().parent().parent().hide(); //es
    $( "div[data-testid='cellInnerDiv'] > div > div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('Tweet sponsorisé')" ).parent().parent().parent().parent().parent().parent().hide(); //fr
    $( "div[data-testid='cellInnerDiv'] > div > div > div > h2 > div[style='-webkit-line-clamp: 3;'] > span:contains('プロモツイート')" ).parent().parent().parent().parent().parent().parent().hide(); //ja - not found

  };

  const config = {childList: true, subtree: true};
  const rootNode = document.querySelector("#react-root");
  if (rootNode != null) {
    const rootObserver = new MutationObserver(rootCallback);
    rootObserver.observe(rootNode, config);
  }

  if (typeof GM_addStyle != 'undefined') {
    GM_addStyle(css);
  } else if (typeof PRO_addStyle != 'undefined') {
    PRO_addStyle(css);
  } else if (typeof addStyle != 'undefined') {
    addStyle(css);
  } else {
    var node = document.createElement('style');
    node.type = 'text/css';
    node.appendChild(document.createTextNode(css));
    document.documentElement.appendChild(node);
  }

})();
