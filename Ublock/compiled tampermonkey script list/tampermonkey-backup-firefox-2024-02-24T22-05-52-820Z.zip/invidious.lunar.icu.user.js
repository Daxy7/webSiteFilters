// ==UserScript==
// @name               invidious.lunar.icu
// @namespace          https://greasyfork.org/en/users/105361-randomusername404
// @description        Always redirects to Invidious, avoiding YT's download speed.
// @match            *://www.youtube.com/*
// @match            *://yewtu.be/*
// @exclude          *://www.youtube.com/embed/*
// @version            1.02
// @run-at             document-start
// @author             RandomUsername404
// @grant              none
// @icon               https://www.youtube.com/favicon.ico
// ==/UserScript==

window.location.replace("https://invidious.lunar.icu" + window.location.pathname + window.location.search);