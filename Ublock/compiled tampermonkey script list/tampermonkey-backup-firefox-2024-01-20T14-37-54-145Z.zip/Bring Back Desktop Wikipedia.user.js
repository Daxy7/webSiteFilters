// ==UserScript==
// @name               Bring Back Desktop Wikipedia
// @namespace          https://greasyfork.org/en/users/105361-randomusername404
// @description        Always redirects to Desktop, avoiding the Mobile redesign.
// @match            *://en.m.wikipedia.org/*
// @version            1.02
// @run-at             document-start
// @author             RandomUsername404
// @grant              none
// @icon
// ==/UserScript==

window.location.replace("https://wikipedia.org" + window.location.pathname + window.location.search);