// ==UserScript==
// @name               Bring Back Desktop Facebook
// @namespace          https://greasyfork.org/en/users/105361-randomusername404
// @description        Always redirects to Desktop, avoiding the Mobile redesign.
// @match            *://m.facebook.com/*
// @version            1.02
// @run-at             document-start
// @author             RandomUsername404
// @grant              none
// @icon
// ==/UserScript==

window.location.replace("https://facebook.com" + window.location.pathname + window.location.search);