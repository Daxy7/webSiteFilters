// ==UserScript==
// @name               Bring Back Fast Twitter
// @namespace          https://greasyfork.org/en/users/105361-randomusername404
// @description        Always redirects to Nitter, avoiding Twitter's download speed.
// @match            *://twitter.com/*
// @version            1.02
// @run-at             document-start
// @author             RandomUsername404
// @grant              none
// @icon               https://nitter.net/logo.png
// ==/UserScript==

window.location.replace("https://nitter.net" + window.location.pathname + window.location.search);